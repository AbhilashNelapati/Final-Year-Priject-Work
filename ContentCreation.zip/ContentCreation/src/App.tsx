import React, { useState } from 'react';
import { Upload, Book, FileVideo, Edit3, MessageSquare, GraduationCap, Plus, X } from 'lucide-react';

type CourseLevel = 'Beginner' | 'Intermediate' | 'Advanced';

type QuestionType = 'multiple-choice' | 'fill-in-blank';

const COURSE_OPTIONS = [
  'Frontend Development',
  'Web Developer',
  'Data Analyst',
  'Backend Development',
  'Full Stack Developer',
  'Mobile App Development',
  'Data Science',
  'Machine Learning',
  'UI/UX Design'
] as const;

type CourseName = typeof COURSE_OPTIONS[number];

interface Option {
  id: string;
  text: string;
}

interface Question {
  id: string;
  type: QuestionType;
  text: string;
  options?: Option[];
  correctAnswers?: string[];
  isMultiSelect?: boolean;
}

interface Assignment {
  id: string;
  title: string;
  description: string;
  questions: Question[];
}

interface CourseData {
  name: CourseName | '';
  customName: string;
  level: CourseLevel;
  videoUrl: string;
  videoTitle: string;
  description: string;
  additionalContent: string;
  assignments: Assignment[];
}

function App() {
  const [courseData, setCourseData] = useState<CourseData>({
    name: '',
    customName: '',
    level: 'Beginner',
    videoUrl: '',
    videoTitle: '',
    description: '',
    additionalContent: '',
    assignments: []
  });

  const [currentStep, setCurrentStep] = useState(1);
  const [feedback, setFeedback] = useState('');
  const [currentQuestionType, setCurrentQuestionType] = useState<QuestionType>('multiple-choice');
  const [showCustomName, setShowCustomName] = useState(false);

  const handleVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      setCourseData({ ...courseData, videoUrl: url });
    }
  };

  const addAssignment = () => {
    const newAssignment: Assignment = {
      id: Date.now().toString(),
      title: '',
      description: '',
      questions: []
    };
    setCourseData({
      ...courseData,
      assignments: [...courseData.assignments, newAssignment]
    });
  };

  const updateAssignment = (id: string, field: keyof Assignment, value: string) => {
    setCourseData({
      ...courseData,
      assignments: courseData.assignments.map(assignment =>
        assignment.id === id ? { ...assignment, [field]: value } : assignment
      )
    });
  };

  const addQuestion = (assignmentId: string) => {
    const newQuestion: Question = {
      id: Date.now().toString(),
      type: currentQuestionType,
      text: '',
      options: currentQuestionType === 'multiple-choice' ? [
        { id: '1', text: '' },
        { id: '2', text: '' }
      ] : undefined,
      correctAnswers: [],
      isMultiSelect: false
    };

    setCourseData({
      ...courseData,
      assignments: courseData.assignments.map(assignment =>
        assignment.id === assignmentId
          ? { ...assignment, questions: [...assignment.questions, newQuestion] }
          : assignment
      )
    });
  };

  const updateQuestion = (assignmentId: string, questionId: string, updates: Partial<Question>) => {
    setCourseData({
      ...courseData,
      assignments: courseData.assignments.map(assignment =>
        assignment.id === assignmentId
          ? {
              ...assignment,
              questions: assignment.questions.map(question =>
                question.id === questionId
                  ? { ...question, ...updates }
                  : question
              )
            }
          : assignment
      )
    });
  };

  const addOption = (assignmentId: string, questionId: string) => {
    setCourseData({
      ...courseData,
      assignments: courseData.assignments.map(assignment =>
        assignment.id === assignmentId
          ? {
              ...assignment,
              questions: assignment.questions.map(question =>
                question.id === questionId && question.options
                  ? {
                      ...question,
                      options: [...question.options, { id: Date.now().toString(), text: '' }]
                    }
                  : question
              )
            }
          : assignment
      )
    });
  };

  const updateOption = (assignmentId: string, questionId: string, optionId: string, text: string) => {
    setCourseData({
      ...courseData,
      assignments: courseData.assignments.map(assignment =>
        assignment.id === assignmentId
          ? {
              ...assignment,
              questions: assignment.questions.map(question =>
                question.id === questionId && question.options
                  ? {
                      ...question,
                      options: question.options.map(option =>
                        option.id === optionId
                          ? { ...option, text }
                          : option
                      )
                    }
                  : question
              )
            }
          : assignment
      )
    });
  };

  const removeOption = (assignmentId: string, questionId: string, optionId: string) => {
    setCourseData({
      ...courseData,
      assignments: courseData.assignments.map(assignment =>
        assignment.id === assignmentId
          ? {
              ...assignment,
              questions: assignment.questions.map(question =>
                question.id === questionId && question.options
                  ? {
                      ...question,
                      options: question.options.filter(option => option.id !== optionId)
                    }
                  : question
              )
            }
          : assignment
      )
    });
  };

  const removeQuestion = (assignmentId: string, questionId: string) => {
    setCourseData({
      ...courseData,
      assignments: courseData.assignments.map(assignment =>
        assignment.id === assignmentId
          ? {
              ...assignment,
              questions: assignment.questions.filter(question => question.id !== questionId)
            }
          : assignment
      )
    });
  };

  const nextStep = () => setCurrentStep(prev => Math.min(prev + 1, 5));
  const prevStep = () => setCurrentStep(prev => Math.max(prev - 1, 1));

  const handleCourseNameChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const value = e.target.value;
    if (value === 'custom') {
      setShowCustomName(true);
      setCourseData({ ...courseData, name: '' });
    } else {
      setShowCustomName(false);
      setCourseData({ ...courseData, name: value as CourseName });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="bg-white rounded-2xl shadow-xl overflow-hidden transition-all duration-200 ease-in-out transform hover:shadow-2xl">
          <div className="p-6 sm:p-8 lg:p-10">
            <div className="flex items-center mb-8">
              <GraduationCap className="w-10 h-10 text-indigo-600 mr-4" />
              <h1 className="text-3xl font-bold text-gray-900">Course Creation</h1>
            </div>

            {/* Progress Steps */}
            <div className="flex justify-between mb-12">
              {[1, 2, 3, 4, 5].map((step) => (
                <div
                  key={step}
                  className={`flex items-center ${
                    step < currentStep
                      ? 'text-indigo-600'
                      : step === currentStep
                      ? 'text-indigo-500'
                      : 'text-gray-300'
                  }`}
                >
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center border-2 transition-all duration-200 ${
                      step <= currentStep ? 'border-indigo-500 bg-indigo-50' : 'border-gray-300'
                    }`}
                  >
                    {step}
                  </div>
                  {step < 5 && (
                    <div
                      className={`w-full h-1 transition-all duration-200 ${
                        step < currentStep ? 'bg-indigo-500' : 'bg-gray-300'
                      }`}
                    />
                  )}
                </div>
              ))}
            </div>

            <div className="overflow-y-auto max-h-[calc(100vh-300px)] pr-4 -mr-4">
              {/* Step 1: Basic Information */}
              {currentStep === 1 && (
                <div className="space-y-6">
                  <div className="grid gap-6 md:grid-cols-2">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Course Name
                      </label>
                      <select
                        value={courseData.name || 'custom'}
                        onChange={handleCourseNameChange}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all duration-200"
                      >
                        <option value="">Select a course</option>
                        {COURSE_OPTIONS.map((course) => (
                          <option key={course} value={course}>
                            {course}
                          </option>
                        ))}
                        <option value="custom">Custom Course</option>
                      </select>
                    </div>

                    {showCustomName && (
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Custom Course Name
                        </label>
                        <input
                          type="text"
                          value={courseData.customName}
                          onChange={(e) => setCourseData({ ...courseData, customName: e.target.value })}
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all duration-200"
                          placeholder="Enter custom course name"
                        />
                      </div>
                    )}

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Course Level
                      </label>
                      <select
                        value={courseData.level}
                        onChange={(e) => setCourseData({ ...courseData, level: e.target.value as CourseLevel })}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all duration-200"
                      >
                        <option value="Beginner">Beginner</option>
                        <option value="Intermediate">Intermediate</option>
                        <option value="Advanced">Advanced</option>
                      </select>
                    </div>
                  </div>
                </div>
              )}

              {/* Step 2: Video Upload */}
              {currentStep === 2 && (
                <div className="space-y-6">
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center transition-all duration-200 hover:border-indigo-500">
                    <Upload className="mx-auto h-16 w-16 text-gray-400" />
                    <div className="mt-4">
                      <label className="cursor-pointer">
                        <span className="mt-2 block text-sm font-medium text-gray-900">
                          Upload video file
                        </span>
                        <input
                          type="file"
                          accept="video/*"
                          onChange={handleVideoUpload}
                          className="hidden"
                        />
                      </label>
                    </div>
                  </div>
                  {courseData.videoUrl && (
                    <div className="mt-4">
                      <video
                        controls
                        className="w-full rounded-lg shadow-lg"
                        src={courseData.videoUrl}
                      />
                    </div>
                  )}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Video Title
                    </label>
                    <input
                      type="text"
                      value={courseData.videoTitle}
                      onChange={(e) => setCourseData({ ...courseData, videoTitle: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all duration-200"
                      placeholder="Enter video title"
                    />
                  </div>
                </div>
              )}

              {/* Step 3: Description and Additional Content */}
              {currentStep === 3 && (
                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Course Description
                    </label>
                    <textarea
                      value={courseData.description}
                      onChange={(e) => setCourseData({ ...courseData, description: e.target.value })}
                      rows={4}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all duration-200"
                      placeholder="Describe your course content"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Additional Resources
                    </label>
                    <textarea
                      value={courseData.additionalContent}
                      onChange={(e) => setCourseData({ ...courseData, additionalContent: e.target.value })}
                      rows={4}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all duration-200"
                      placeholder="Add links to additional resources, articles, or documents"
                    />
                  </div>
                </div>
              )}

              {/* Step 4: Assignments */}
              {currentStep === 4 && (
                <div className="space-y-6">
                  <div className="flex justify-between items-center">
                    <h3 className="text-lg font-medium text-gray-900">Assignments</h3>
                    <button
                      onClick={addAssignment}
                      className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition-all duration-200"
                    >
                      Add Assignment
                    </button>
                  </div>
                  {courseData.assignments.map((assignment) => (
                    <div key={assignment.id} className="border rounded-lg p-6 space-y-4 transition-all duration-200 hover:shadow-md">
                      <input
                        type="text"
                        value={assignment.title}
                        onChange={(e) => updateAssignment(assignment.id, 'title', e.target.value)}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all duration-200"
                        placeholder="Assignment title"
                      />
                      <textarea
                        value={assignment.description}
                        onChange={(e) => updateAssignment(assignment.id, 'description', e.target.value)}
                        rows={3}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all duration-200"
                        placeholder="Assignment description"
                      />
                      
                      {/* Questions Section */}
                      <div className="mt-6 space-y-4">
                        <div className="flex items-center justify-between">
                          <h4 className="text-md font-medium text-gray-700">Questions</h4>
                          <div className="flex items-center space-x-4">
                            <select
                              value={currentQuestionType}
                              onChange={(e) => setCurrentQuestionType(e.target.value as QuestionType)}
                              className="px-3 py-1 border border-gray-300 rounded-md text-sm transition-all duration-200"
                            >
                              <option value="multiple-choice">Multiple Choice</option>
                              <option value="fill-in-blank">Fill in the Blank</option>
                            </select>
                            <button
                              onClick={() => addQuestion(assignment.id)}
                              className="flex items-center px-3 py-1 bg-indigo-100 text-indigo-700 rounded-md hover:bg-indigo-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition-all duration-200"
                            >
                              <Plus className="w-4 h-4 mr-1" />
                              Add Question
                            </button>
                          </div>
                        </div>

                        {assignment.questions.map((question, qIndex) => (
                          <div key={question.id} className="bg-gray-50 p-4 rounded-lg space-y-3 transition-all duration-200 hover:bg-gray-100">
                            <div className="flex justify-between items-start">
                              <label className="block text-sm font-medium text-gray-700">
                                Question {qIndex + 1}
                              </label>
                              <button
                                onClick={() => removeQuestion(assignment.id, question.id)}
                                className="text-red-600 hover:text-red-800 transition-colors duration-200"
                              >
                                <X className="w-4 h-4" />
                              </button>
                            </div>
                            
                            <input
                              type="text"
                              value={question.text}
                              onChange={(e) => updateQuestion(assignment.id, question.id, { text: e.target.value })}
                              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all duration-200"
                              placeholder={question.type === 'multiple-choice' ? 'Enter question' : 'Enter question with ___ for blanks'}
                            />

                            {question.type === 'multiple-choice' && (
                              <div className="space-y-2">
                                <div className="flex items-center space-x-2">
                                  <label className="text-sm text-gray-600">
                                    <input
                                      type="checkbox"
                                      checked={question.isMultiSelect}
                                      onChange={(e) => updateQuestion(assignment.id, question.id, { isMultiSelect: e.target.checked })}
                                      className="mr-2"
                                    />
                                    Allow multiple selections
                                  </label>
                                </div>
                                
                                {question.options?.map((option) => (
                                  <div key={option.id} className="flex items-center space-x-2">
                                    <input
                                      type="text"
                                      value={option.text}
                                      onChange={(e) => updateOption(assignment.id, question.id, option.id, e.target.value)}
                                      className="flex-1 px-3 py-1 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all duration-200"
                                      placeholder="Enter option"
                                    />
                                    <button
                                      onClick={() => removeOption(assignment.id, question.id, option.id)}
                                      className="text-red-600 hover:text-red-800 transition-colors duration-200"
                                    >
                                      <X className="w-4 h-4" />
                                    </button>
                                  </div>
                                ))}
                                
                                <button
                                  onClick={() => addOption(assignment.id, question.id)}
                                  className="text-sm text-indigo-600 hover:text-indigo-800 transition-colors duration-200"
                                >
                                  + Add Option
                                </button>
                              </div>
                            )}

                            {question.type === 'fill-in-blank' && (
                              <div className="space-y-2">
                                <input
                                  type="text"
                                  value={question.correctAnswers?.[0] || ''}
                                  onChange={(e) => updateQuestion(assignment.id, question.id, { correctAnswers: [e.target.value] })}
                                  className="w-full px-3 py-1 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all duration-200"
                                  placeholder="Enter correct answer"
                                />
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Step 5: Feedback */}
              {currentStep === 5 && (
                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Course Feedback
                    </label>
                    <textarea
                      value={feedback}
                      onChange={(e) => setFeedback(e.target.value)}
                      rows={4}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all duration-200"
                      placeholder="Provide feedback about the course"
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Navigation Buttons */}
            <div className="mt-8 flex justify-between">
              <button
                onClick={prevStep}
                disabled={currentStep === 1}
                className={`px-6 py-2 rounded-lg transition-all duration-200 ${
                  currentStep === 1
                    ? 'bg-gray-300 cursor-not-allowed'
                    : 'bg-gray-600 text-white hover:bg-gray-700'
                }`}
              >
                Previous
              </button>
              <button
                onClick={nextStep}
                disabled={currentStep === 5}
                className={`px-6 py-2 rounded-lg transition-all duration-200 ${
                  currentStep === 5
                    ? 'bg-gray-300 cursor-not-allowed'
                    : 'bg-indigo-600 text-white hover:bg-indigo-700'
                }`}
              >
                {currentStep === 4 ? 'Finish' : 'Next'}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;