import React from "react";

const Dashboard = () => {
  return (
    <div className="grid grid-cols-3 gap-6">
      <div className="bg-white p-6 shadow-lg rounded-lg">
        <h3 className="text-xl font-bold">Total Courses</h3>
        <p className="text-gray-600 text-3xl font-semibold mt-2">12</p>
      </div>
      <div className="bg-white p-6 shadow-lg rounded-lg">
        <h3 className="text-xl font-bold">Total Students</h3>
        <p className="text-gray-600 text-3xl font-semibold mt-2">120</p>
      </div>
      <div className="bg-white p-6 shadow-lg rounded-lg">
        <h3 className="text-xl font-bold">Pending Assignments</h3>
        <p className="text-gray-600 text-3xl font-semibold mt-2">5</p>
      </div>
    </div>
  );
};

export default Dashboard;
